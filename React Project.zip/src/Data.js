// Data.js
import menuImage1 from "./assets/images/menu-1.png";
import menuImage2 from "./assets/images/menu-2.png";
import menuImage3 from "./assets/images/menu-3.png";
import menuImage4 from "./assets/images/menu-4.png";
import menuImage5 from "./assets/images/menu-5.png";
import menuImage6 from "./assets/images/menu-6.png";

const menu = [
  {
    id: 1,
    name: "Menu Item 1",
    img: menuImage1,
    price: 15.99,
  },
  {
    id: 2,
    name: "Menu Item 2",
    img: menuImage2,
    price: 17.99,
  },
  {
    id: 3,
    name: "Menu Item 3",
    img: menuImage3,
    price: 12.99,
  },
  {
    id: 4,
    name: "Menu Item 4",
    img: menuImage4,
    price: 18.99,
  },
  {
    id: 5,
    name: "Menu Item 5",
    img: menuImage5,
    price: 14.99,
  },
  {
    id: 6,
    name: "Menu Item 6",
    img: menuImage6,
    price: 19.99,
  },
];

export { menu };
