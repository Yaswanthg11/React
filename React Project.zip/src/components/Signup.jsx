import React, { useState } from 'react';
import Logo from '../assets/images/logo.png'; // Update the path to your logo
import { Link, useNavigate } from 'react-router-dom';
import '../assets/css/signup.css';

const SignUp = () => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const validatePassword = (password) => {
        const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        return regex.test(password);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (password !== confirmPassword) {
            setError('Passwords do not match.');
            return;
        }

        if (!validatePassword(password)) {
            setError('Password must contain at least one uppercase letter, one lowercase letter, one number, one special character, and be at least 8 characters long.');
            return;
        }

        if (!/^\d{10}$/.test(phone)) {
            setError('Phone number must be a numeric string of length 10.');
            return;
        }

        // Send the user data to the backend
        try {
            const response = await fetch('http://localhost:5000/signup', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, email, phone, password }),
            });

            const data = await response.json();

            if (!response.ok) {
                setError(data.message); // Display error from backend
                return;
            }

            // If signup is successful, navigate to the 'homelogged' component
            navigate('/homelogged');
        } catch (error) {
            setError('An error occurred while signing up. Please try again.');
        }
    };

    return (
        <div className="signup-page">
            <header className="header">
                <a href="#logo" className="logo">
                    <img src={Logo} alt="Logo" />
                </a>
                <nav className="navbar">
                    <a href="/">Home</a>
                    <a href="/#about">About</a>
                    <a href="/#contact">Contact</a>
                    <Link to="/menu">
                        <a href="#menu">Menu</a>
                    </Link>
                </nav>
            </header>

            <section className="signup-section">
                <h1 className="signup-heading">Sign Up</h1>
                <form className="signup-form" onSubmit={handleSubmit}>
                    <div className="inputRow">
                        <label htmlFor="username">Username</label>
                        <input 
                            type="text" 
                            id="username" 
                            value={username}
                            onChange={(e) => setUsername(e.target.value)} 
                            required 
                        />
                    </div>
                    <div className="inputRow">
                        <label htmlFor="email">Email</label>
                        <input 
                            type="email" 
                            id="email" 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)} 
                            required 
                        />
                    </div>
                    <div className="inputRow">
                        <label htmlFor="phone">Phone Number</label>
                        <input 
                            type="tel" 
                            id="phone" 
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)} 
                            required 
                        />
                    </div>
                    <div className="inputRow">
                        <label htmlFor="password">Password</label>
                        <input 
                            type="password" 
                            id="password" 
                            value={password}
                            onChange={(e) => setPassword(e.target.value)} 
                            required 
                        />
                    </div>
                    <div className="inputRow">
                        <label htmlFor="confirm-password">Confirm Password</label>
                        <input 
                            type="password" 
                            id="confirm-password" 
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)} 
                            required 
                        />
                    </div>
                    {error && <p className="error-message" style={{ color: 'white' }}>{error}</p>}
                    <button type="submit" className="signup-submit-btn">Sign Up</button>
                </form>
                <p className="login-link">
                    Already have an account? <Link to="/login">Login here</Link>
                </p>
            </section>
        </div>
    );
};

export default SignUp;
