import { useRef, useContext } from "react";
import { Link } from 'react-router-dom';
import Logo from "../assets/images/logo.png";
import ProfileAvatar from "../assets/images/avatar.png";
import { menu } from "../Data";
import { CartContext } from "./CartContext";
import "../assets/css/style.css";

const Menu = () => {
  const navbarRef = useRef();
  const cartRef = useRef();
  const { addToCart } = useContext(CartContext); // Use cart context

      const navbarHandler = () => {
    navbarRef.current.classList.toggle("active");
    cartRef.current.classList.remove("active");
  };

  const cartHandler = (item) => {
    addToCart(item); // Add item to cart using context function
  };

  return (
    <div>
      <header className="header">
        <Link to="/" className="logo">
          <img src={Logo} alt="Logo" />
        </Link>
        <nav className="navbar" ref={navbarRef}>
          <Link to="/homelogged">Home</Link>
          <Link to="/homelogged">About</Link>
          <Link to="/homelogged">Contact</Link>
          <Link to="/menu">Menu</Link>
          <Link to="/cart">Cart</Link>
        </nav>
        <div className="icons">
          <img
            src={ProfileAvatar}
            alt="Profile Avatar"
            className="profile-avatar"
            style={{ width: "40px", height: "40px", cursor: "pointer" }}
          />
          <div
            className="fas fa-bars"
            id="menu-btn"
            onClick={navbarHandler}
          ></div>
        </div>
      </header>
      <section className="menu" id="menu">
        <h1 className="heading">
          our <span>menu</span>
        </h1>
        <div className="box-container">
          {menu.map((item, index) => (
            <div className="box" key={index}>
              <img src={item.img} alt="" />
              <h3>tasty and healthy</h3>
              <div className="price">
                $15.99 <span>$20.99</span>
              </div>
              <button className="btn" onClick={() => cartHandler(item)}>
                add to cart
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Menu;
