/* eslint-disable jsx-a11y/anchor-has-content */
import { useState, useRef } from "react";
import axios from 'axios';
import { Link } from 'react-router-dom';
import Logo from "../assets/images/logo.png";
import AboutImg from "../assets/images/about-img";
import ProfileAvatar from "../assets/images/avatar.png";
import "../assets/css/style.css";
const HomeLogged = () => {
  const navbarRef = useRef();
  const searchRef = useRef();
  const cartRef = useRef();

  const navbarHandler = () => {
    navbarRef.current.classList.toggle("active");
    searchRef.current.classList.remove("active");
    cartRef.current.classList.remove("active");
  };

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [number, setNumber] = useState('');
  const [message, setMessage] = useState(''); // To display success/failure message

  const handleContactSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/contact', {
        name,
        email,
        number
      });
      setMessage(response.data.message); // Display success message
      setName(''); // Reset form fields
      setEmail('');
      setNumber('');
    } catch (error) {
      setMessage('Failed to send contact details.');
    }
};

  return (
    <div>
      <header className="header">
        <a href="#logo" className="logo">
          <img src={Logo} alt="" />
        </a>
        <nav className="navbar" ref={navbarRef}>
          <a href="#home">Home</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
          <Link to="/menu">
          <a href="#menu">Menu</a>
          </Link> 
          <Link to="/cart">Cart</Link>
        </nav>
        <div className="icons">
        <img
              src={ProfileAvatar}
              alt="Profile Avatar"
              className="profile-avatar"
              style={{ width: "40px", height: "40px", cursor: "pointer" }}
            />

          <div
            className="fas fa-bars"
            id="menu-btn"
            onClick={navbarHandler}
          ></div>
        </div>

      </header>

      <section className="home" id="home">
        <div className="content">
          <h3>
            Fresh <span>food in the </span>morning
          </h3>
          <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat
            labore, sint cupiditate distinctio tempora reic iendis.
          </p>
          <Link to="/menu">
          <a href="#products" className="btn">
            get yours now
          </a>
          </Link>
        </div>
      </section>

      <section className="about" id="about">
        <h1 className="heading">
          <span>about</span> us
        </h1>

        <div className="row">
          <div className="image">
            <img src={AboutImg} alt="" />
          </div>

          <div className="content">
            <h3>what makes our food special?</h3>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit.
              Voluptatibus qui ea ullam, enim tempora ipsum fuga alias quae
              ratione a officiis id temporibus autem? Quod nemo facilis
              cupiditate. Ex, vel?
            </p>
            <p>
              Lorem ipsum dolor sit amet consectetur, adipisicing elit. Odit
              amet enim quod veritatis, nihil voluptas culpa! Neque consectetur
              obcaecati sapiente?
            </p>
          </div>
        </div>
      </section>

      <section className="contact" id="contact">
      <h1 className="heading">
        <span>contact</span> us
      </h1>
      <div className="row">
        <iframe
          className="map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13499.14883856849!2d76.94560240504474!3d10.93573219003504!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba85bbadd6c26b7%3A0x64f730d864d6bbff!2s007%20Punjab%20Dhaba!5e0!3m2!1sen!2sin!4v1730031661788!5m2!1sen!2sin"
          allowFullScreen=""
          loading="lazy"
          title="maps"
        ></iframe>

        <form onSubmit={handleContactSubmit}>
          <h3>get in touch</h3>
          <div className="inputBox">
            <span className="fas fa-user"></span>
            <input
              type="text"
              placeholder="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="inputBox">
            <span className="fas fa-envelope"></span>
            <input
              type="email"
              placeholder="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="inputBox">
            <span className="fas fa-phone"></span>
            <input
              type="number"
              placeholder="number"
              value={number}
              onChange={(e) => setNumber(e.target.value)}
              required
            />
          </div>
          <input type="submit" value="contact now" className="btn" />
          {message && <p>{message}</p>} {/* Message display */}
        </form>
      </div>
    </section>

      <section class="footer">
  <div class="footer-content">
    <div class="location-hours">
      <div class="location">
        <h3>Location</h3>
        <p>Foodie Pie</p>
        <p>112 West Main Street, Alhambra, CA, 91801, United States</p>
      </div>
      <div class="hours">
        <h3>Hours</h3>
        <p>MONDAY - THURSDAY: 11:30 AM - 9:00 PM</p>
        <p>FRIDAY - SATURDAY: 11:30 AM - 10:00 PM</p>
        <p>SUNDAY: 11:30 AM - 9:00 PM</p>
      </div>
    </div>
    <div class="share">
      <a href="#facebook" class="fab fa-facebook-f"></a>
      <a href="#twitter" class="fab fa-twitter"></a>
      <a href="#instagram" class="fab fa-instagram"></a>
    </div>
  </div>
</section>

    </div>
  );
};

export default HomeLogged;
