import React, { useState } from 'react';
import Logo from '../assets/images/logo.png'; // Update the path to your logo
import { Link, useNavigate } from 'react-router-dom';
import '../assets/css/login.css';

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        // Send the login data to the backend for authentication
        try {
            const response = await fetch('http://localhost:5000/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });

            const data = await response.json();

            if (!response.ok) {
                setError(data.message); // Display error from backend
                return;
            }

            // If login is successful, navigate to the 'homelogged' component
            navigate('/homelogged');
        } catch (error) {
            setError('An error occurred while logging in. Please try again.');
        }
    };

    return (
        <div className="login-page">
            <header className="header">
                <Link to="/" className="logo">
                    <img src={Logo} alt="Logo" />
                </Link>
                <nav className="navbar">
                    <Link to="/#home">Home</Link>
                    <Link to="/#about">About</Link>
                    <Link to="/#contact">Contact</Link>
                    <Link to="/menu">
                        <a href="#menu">Menu</a>
                    </Link>
                </nav>
            </header>

            <section className="login-section">
                <h1 className="login-heading">Login</h1>
                <form className="login-form" onSubmit={handleSubmit}>
                    <div className="inputBox">
                        <label htmlFor="username">Username</label>
                        <input 
                            type="text" 
                            id="username" 
                            value={username}
                            onChange={(e) => setUsername(e.target.value)} 
                            required 
                        />
                    </div>
                    <div className="inputBox">
                        <label htmlFor="password">Password</label>
                        <input 
                            type="password" 
                            id="password" 
                            value={password}
                            onChange={(e) => setPassword(e.target.value)} 
                            required 
                        />
                    </div>
                    {error && <p className="error-message" style={{ color: 'white' }}>{error}</p>}
                    <button type="submit" className="login-submit-btn">Login</button>
                </form>
                <div className="signup-link">
                    <p>Don't have an account? <Link to="/signup">Sign up</Link></p>
                </div>
            </section>
        </div>
    );
};

export default Login;
