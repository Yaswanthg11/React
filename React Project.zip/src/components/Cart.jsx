// Cart.jsx
import React, { useRef, useContext } from 'react';
import { Link } from 'react-router-dom';
import Logo from '../assets/images/logo.png';
import ProfileAvatar from '../assets/images/avatar.png';
import { CartContext } from './CartContext';
import '../assets/css/cart.css';

const Cart = () => {
    const { cartItems, incrementQuantity, decrementQuantity, removeFromCart, clearCart } = useContext(CartContext);
    const navbarRef = useRef();
    const cartRef = useRef();

    const navbarHandler = () => {
        navbarRef.current.classList.toggle("active");
        cartRef.current.classList.remove("active");
    };

    return (
        <div className="cart">
            <header className="header">
                <Link to="/" className="logo">
                    <img src={Logo} alt="Logo" />
                </Link>
                <nav className="navbar" ref={navbarRef}>
                    <Link to="/homelogged">Home</Link>
                    <Link to="/homelogged">About</Link>
                    <Link to="/homelogged">Contact</Link>
                    <Link to="/menu">Menu</Link>
                    <Link to="/cart">Cart</Link>
                </nav>
                <div className="icons">
                    <img
                        src={ProfileAvatar}
                        alt="Profile Avatar"
                        className="profile-avatar"
                        style={{ width: "40px", height: "40px", cursor: "pointer" }}
                    />
                    <div
                        className="fas fa-bars"
                        id="menu-btn"
                        onClick={navbarHandler}
                    ></div>
                </div>
            </header>
            <h2>Your Cart</h2>
            {cartItems.length === 0 ? (
                <p className="cart-empty">Your cart is empty</p>
            ) : (
                <div className="cart-items-grid">
                    {cartItems.map((item) => (
                        <div className="cart-item" key={item.id}>
                            <img src={item.img} alt={item.name} className="cart-item-image" />
                            <div className="cart-item-details">
                                <h3>{item.name}</h3>
                                <p>Price: ${item.price * item.quantity}</p> {/* Total price calculation */}
                                <div className="cart-item-quantity">
                                    <button onClick={() => decrementQuantity(item.id)}>-</button>
                                    <span>{item.quantity}</span>
                                    <button onClick={() => incrementQuantity(item.id)}>+</button>
                                </div>
                            </div>
                            <button onClick={() => removeFromCart(item.id)} className="remove-btn">
                                Remove
                            </button>
                        </div>
                    ))}
                </div>
            )}
            {cartItems.length > 0 && (
                <div className="cart-actions">
                    <button onClick={clearCart} className="checkout-btn">
                        Checkout Now
                    </button>
                </div>
            )}
        </div>
    );
};

export default Cart;
