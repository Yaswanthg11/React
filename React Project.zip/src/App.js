import React from "react";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from "./components/Home";
import Login from "./components/Login";
import SignUp from "./components/Signup";
import Menu from "./components/Menu";
import HomeLogged from "./components/Homelogged";
import Cart from "./components/Cart";
import { CartProvider } from "./components/CartContext";

function App() {
  return (
    <Router>
      <CartProvider> {/* Wrap CartProvider around Routes */}
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/login" element={<Login />} />
          <Route exact path="/signup" element={<SignUp />} />
          <Route exact path="/menu" element={<Menu />} />
          <Route exact path="/homelogged" element={<HomeLogged />} />
          <Route exact path="/cart" element={<Cart />} /> {/* Add Cart Route */}
        </Routes>
      </CartProvider>
    </Router>
  );
}

export default App;
