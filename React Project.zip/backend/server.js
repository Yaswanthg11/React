const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const jwt = require('jsonwebtoken'); // Import jsonwebtoken
const app = express();
const secretKey = 'your_secret_key'; // Change this to a more secure key in production

app.use(cors());
app.use(bodyParser.json());

// Route for signup (to store user)
app.post('/signup', (req, res) => {
  const { username, email, phone, password } = req.body;
  const users = JSON.parse(fs.readFileSync('./data/users.json'));

  // Check if user exists
  const userExists = users.some(user => user.username === username);
  if (userExists) {
    return res.status(400).json({ message: 'User already exists!' });
  }

  // Create a token
  const token = jwt.sign({ password }, secretKey);

  // Add user with tokenized password
  users.push({ id: users.length + 1, username, email, phone, password: token });
  fs.writeFileSync('./data/users.json', JSON.stringify(users));
  res.status(201).json({ message: 'User registered successfully!' });
});

// Route for login (to authenticate user)
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const users = JSON.parse(fs.readFileSync('./data/users.json'));

  // Find user by username
  const user = users.find(user => user.username === username);
  if (!user) {
    return res.status(400).json({ message: 'User does not exist!' });
  }

  // Verify password using token
  try {
    const decoded = jwt.verify(user.password, secretKey);
    if (decoded.password !== password) {
      return res.status(400).json({ message: 'Password is incorrect!' });
    }
  } catch (err) {
    return res.status(400).json({ message: 'Password is incorrect!' });
  }

  res.status(200).json({ message: 'Login successful!' });
});

// Start server
app.listen(5000, () => {
  console.log('Server running on port 5000');
});










// Route for contact form submission
app.post('/contact', (req, res) => {
    const { name, email, number } = req.body;
    const contacts = JSON.parse(fs.readFileSync('./data/contact.json', 'utf-8'));
  
    // Append the new contact
    contacts.push({ id: contacts.length + 1, name, email, number });
    
    // Write updated contacts list back to the file
    fs.writeFileSync('./data/contact.json', JSON.stringify(contacts, null, 2));
    res.status(201).json({ message: 'Contact information saved successfully!' });
  });
  